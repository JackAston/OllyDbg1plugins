//---------------------------------------------------------------------------

#include <windows.h>
#include <stdio.h>
#include <string.h>
#include <classes.hpp>
//---------------------------------------------------------------------------
// DLLBreakEx ODBG Plugin v1.1
// By E3 - 21 May 2004
//---------------------------------------------------------------------------
#include "plugin.h"
//---------------------------------------------------------------------------
t_module *pmodule;

HINSTANCE        hdll;                // DLL instance
HWND             hwmain;              // Handle of main OllyDbg window

TStringList *    aDLL;
TStringList *    aMOD;

char PLUGIN_MENU[] = "\
0 Add &Named DLL Breakpoint..., \
1 &List Named DLL Breakpoints, \
2 &Remove Named DLL Breakpoints |\
3 &About";

char MODULES_MENU[] = "\
0 Add &Named DLL Breakpoint..., \
1 &List Named DLL Breakpoints, \
2 &Remove Named DLL Breakpoints |";

String sVersion = "v1.1";

//---------------------------------------------------------------------------
int WINAPI DllEntryPoint(HINSTANCE hinst, unsigned long reason, void* lpReserved)
{
  if (reason==DLL_PROCESS_ATTACH)
    hdll=hinst;                        // Mark plugin instance
  return 1;                            // Report success
};
//---------------------------------------------------------------------------
int _export cdecl ODBG_Plugindata(char shortname[32]) {
  strcpy(shortname,"DLLBreakEx");      // Name of plugin
  return PLUGIN_VERSION;
};
//---------------------------------------------------------------------------
int _export cdecl ODBG_Plugininit(int ollydbgversion,HWND hw,ulong *features) {
  if (ollydbgversion<PLUGIN_VERSION)
    return -1;
  hwmain=hw;
  String S = "DLLBreakEx "+sVersion+" by E3";
  Addtolist(0,0,S.c_str());
  aDLL = new TStringList;
  aMOD = new TStringList;
  return 0;
};
//---------------------------------------------------------------------------
void _export cdecl ODBG_Pluginreset(void) {
  //Clear internal cache of loaded modules (on restart/new)
  aMOD->Clear();
}
//---------------------------------------------------------------------------
void _export cdecl ODBG_Plugindestroy(void) {
  aMOD->Clear(); delete aMOD;
  aDLL->Clear(); delete aDLL;
};
//---------------------------------------------------------------------------
int _export cdecl ODBG_Pluginmenu(int origin,char data[4096],void *item)  {
  int i,n;
  t_dump *pd;
  switch (origin) {
    case PM_MAIN:                      // Plugin menu in main window
      strcpy(data,PLUGIN_MENU);
      return 1;
//    case PM_MODULES:
//      strcpy(data,MODULES_MENU);
//      return 1;
    default: break;                    // Any other window
  };
  return 0;                            // Window not supported by plugin
};
//---------------------------------------------------------------------------
void information(String sMsg)
{
  String S = "DLLBreakEx "+sVersion;
  MessageBox(hwmain,sMsg.c_str(), S.c_str(),MB_OK|MB_ICONINFORMATION);
}
//---------------------------------------------------------------------------
void _export cdecl ODBG_Pluginaction(int origin,int action,void *item) {
  if (origin==PM_MAIN) {
    String S;
    switch (action) {
      case 0:
        char path[255];
        Browsefilename("Select library",path,".dll",0);
        if (strlen(path)) {
         int f=0;
         if (!aDLL->Find(path,f))
         {
          aDLL->Add(UpperCase(path));
          aDLL->Sort();
          S = ExtractFileName(path);
          S = S + " added to list.";
          information(S);
        }}
        break;
      case 1:
        if (aDLL->Text.Length()) information(aDLL->Text);
        break;
      case 2:
        aDLL->Clear();
        information("DLL list has been cleared");
        break;
      case 3:
        // Menu item "About", displays plugin info.
        information("DLLBreakEx "+sVersion+" by E3\n\nDescription:\nWarn on specified DLL Load.\nNeed DLL Break on new DLL in Debugging Options / Events.");
        break;
      default: break;
    }; }
  };
;
//---------------------------------------------------------------------------
int _export cdecl ODBG_Paused(int reason,t_reg *reg) {
  if ((reason&PP_PAUSE)!=1) return 0;
  if (!aDLL->Count) return 0;
  
  t_table* tt;
  tt = (t_table*) Plugingetvalue(VAL_MODULES);

  int L = tt->data.itemsize;

  char* item = StrAlloc(L);

  bool bfound=false;

  int ptr, f=0;
  t_module* module;
  for (int n=tt->data.n-1;n>=0;n--) {
    ptr = (int)tt->data.data + n*L;
    module = (t_module*) ptr;
    if (!aMOD->Find(UpperCase(module->path),f)) {

      aMOD->Add(UpperCase(module->path)); aMOD->Sort();

      bfound = bfound | aDLL->Find(UpperCase(module->path),f);
    }
  }

  StrDispose(item);

  if (bfound)
    information("DLLBreakEx Breakpoint !");
  else {
    //ignore bad dlls load breakpoint
    PostMessage(hwmain,WM_KEYDOWN,VK_F9,0);
  }

  return 0;
}
//---------------------------------------------------------------------------

