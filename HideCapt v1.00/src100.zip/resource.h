#define IDD_HIDECAPTOPT                 101
#define IDC_HIDECAPTONSTART             1001
#define IDC_NOTHICKFRAME                1002
