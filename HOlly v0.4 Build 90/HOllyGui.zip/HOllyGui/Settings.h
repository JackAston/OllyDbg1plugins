#pragma once

#include <string>
#include <boost/signal.hpp>

namespace HOlly
{

	class Settings
	{
		std::string Path;

		std::map<std::string, std::string> Storage;

		bool FindByKey(const std::string& str, std::string& out);

	public:

		virtual const int& Get(const std::string& name, const int& def = 0);
		virtual const std::string& Get(const std::string& name, const std::string& def = "");

		virtual void Set(const std::string& name, const int& val);
		virtual void Set(const std::string& name, const std::string& val);

		virtual void Save();
		virtual void Clear();

		boost::signal<void ()> Changed;

		void SetIniPath(std::string path);
	};


}