#pragma once

#include <vector>
#include <string>

namespace HOlly
{
	class PatchManager
	{
		virtual std::vector<std::string> GetNames();
		virtual std::string GetDescription(const std::string& name);
		virtual bool GetEnabled(const std::string& name);
	};
}