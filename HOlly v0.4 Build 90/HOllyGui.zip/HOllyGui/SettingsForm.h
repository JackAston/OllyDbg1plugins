#pragma once

#include "Settings.h"

using namespace System;
using namespace System::ComponentModel;
using namespace System::Collections;
using namespace System::Windows::Forms;
using namespace System::Data;
using namespace System::Drawing;


namespace HOllyGui {

	/// <summary>
	/// Summary for SettingsForm
	///
	/// WARNING: If you change the name of this class, you will need to change the
	///          'Resource File Name' property for the managed resource compiler tool
	///          associated with all .resx files this class depends on.  Otherwise,
	///          the designers will not be able to interact properly with localized
	///          resources associated with this form.
	/// </summary>
	public ref class SettingsForm : public System::Windows::Forms::Form
	{
	public:
		HOlly::Settings* Sets;

		SettingsForm(void)
		{
			InitializeComponent();
			//
			//TODO: Add the constructor code here
			//
		}

	protected:
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		~SettingsForm()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::CheckBox^  ColorMaskCB;
	protected: 

	private: System::Windows::Forms::CheckBox^  CopyFormatCB;
	protected: 

	private: System::Windows::Forms::CheckBox^  FollowDumpCB;

	private: System::Windows::Forms::CheckBox^  LogHideCB;

	private: System::Windows::Forms::CheckBox^  SSEFixCB;
	private: System::Windows::Forms::ComboBox^  ColorMaskFore;
	private: System::Windows::Forms::CheckBox^  HideDllLoadCB;
	private: System::Windows::Forms::CheckBox^  HideDllUnloadCB;
	private: System::Windows::Forms::CheckBox^  HideBreakpointCB;
	private: System::Windows::Forms::Button^  CancelBtn;
	private: System::Windows::Forms::Button^  SaveBtn;
	private: System::Windows::Forms::ComboBox^  ColorMaskBack;




	private: System::Void SettingsForm_Load(System::Object^  sender, System::EventArgs^  e) 
			 {
				 unsigned int fore = Sets->Get("ColorMask-Foreground", 12);
				 unsigned int back = (unsigned int)Sets->Get("ColorMask-Background", 16)  >> 4;
				 ColorMaskFore->SelectedIndex = (fore < ColorMaskFore->Items->Count) ? fore : 12;
				 ColorMaskBack->SelectedIndex = (back < ColorMaskBack->Items->Count) ? back : 1;
				 ColorMaskCB->Checked = Sets->Get("ColorMask-Enabled", 0);

				 CopyFormatCB->Checked = Sets->Get("CopyFormat-Enabled", 0);
				 FollowDumpCB->Checked = Sets->Get("FollowDump-Enabled", 0);
				 SSEFixCB->Checked = Sets->Get("SSEFix-Enabled", 0);
				 LogHideCB->Checked = Sets->Get("LogHide-Enabled", 0);

				 int mask = Sets->Get("LogHide-HideMask", 0);
				 
				 if (mask & 1)
					 HideDllLoadCB->Checked = true;
				 if (mask & 2)
					 HideDllUnloadCB->Checked = true;
				 if (mask & 4)
					 HideBreakpointCB->Checked = true;

			 }


	private:
		/// <summary>
		/// Required designer variable.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		void InitializeComponent(void)
		{
			this->ColorMaskCB = (gcnew System::Windows::Forms::CheckBox());
			this->CopyFormatCB = (gcnew System::Windows::Forms::CheckBox());
			this->FollowDumpCB = (gcnew System::Windows::Forms::CheckBox());
			this->LogHideCB = (gcnew System::Windows::Forms::CheckBox());
			this->SSEFixCB = (gcnew System::Windows::Forms::CheckBox());
			this->ColorMaskFore = (gcnew System::Windows::Forms::ComboBox());
			this->ColorMaskBack = (gcnew System::Windows::Forms::ComboBox());
			this->HideDllLoadCB = (gcnew System::Windows::Forms::CheckBox());
			this->HideDllUnloadCB = (gcnew System::Windows::Forms::CheckBox());
			this->HideBreakpointCB = (gcnew System::Windows::Forms::CheckBox());
			this->CancelBtn = (gcnew System::Windows::Forms::Button());
			this->SaveBtn = (gcnew System::Windows::Forms::Button());
			this->SuspendLayout();
			// 
			// ColorMaskCB
			// 
			this->ColorMaskCB->AutoSize = true;
			this->ColorMaskCB->Location = System::Drawing::Point(131, 12);
			this->ColorMaskCB->Name = L"ColorMaskCB";
			this->ColorMaskCB->Size = System::Drawing::Size(76, 17);
			this->ColorMaskCB->TabIndex = 0;
			this->ColorMaskCB->Text = L"ColorMask";
			this->ColorMaskCB->UseVisualStyleBackColor = true;
			this->ColorMaskCB->CheckedChanged += gcnew System::EventHandler(this, &SettingsForm::ColorMaskCB_CheckedChanged);
			// 
			// CopyFormatCB
			// 
			this->CopyFormatCB->AutoSize = true;
			this->CopyFormatCB->Location = System::Drawing::Point(12, 12);
			this->CopyFormatCB->Name = L"CopyFormatCB";
			this->CopyFormatCB->Size = System::Drawing::Size(82, 17);
			this->CopyFormatCB->TabIndex = 1;
			this->CopyFormatCB->Text = L"CopyFormat";
			this->CopyFormatCB->UseVisualStyleBackColor = true;
			this->CopyFormatCB->CheckedChanged += gcnew System::EventHandler(this, &SettingsForm::CopyFormatCB_CheckedChanged);
			// 
			// FollowDumpCB
			// 
			this->FollowDumpCB->AutoSize = true;
			this->FollowDumpCB->Location = System::Drawing::Point(12, 35);
			this->FollowDumpCB->Name = L"FollowDumpCB";
			this->FollowDumpCB->Size = System::Drawing::Size(84, 17);
			this->FollowDumpCB->TabIndex = 2;
			this->FollowDumpCB->Text = L"FollowDump";
			this->FollowDumpCB->UseVisualStyleBackColor = true;
			this->FollowDumpCB->CheckedChanged += gcnew System::EventHandler(this, &SettingsForm::FollowDumpCB_CheckedChanged);
			// 
			// LogHideCB
			// 
			this->LogHideCB->AutoSize = true;
			this->LogHideCB->Location = System::Drawing::Point(271, 12);
			this->LogHideCB->Name = L"LogHideCB";
			this->LogHideCB->Size = System::Drawing::Size(66, 17);
			this->LogHideCB->TabIndex = 3;
			this->LogHideCB->Text = L"LogHide";
			this->LogHideCB->UseVisualStyleBackColor = true;
			this->LogHideCB->CheckedChanged += gcnew System::EventHandler(this, &SettingsForm::LogHideCB_CheckedChanged);
			// 
			// SSEFixCB
			// 
			this->SSEFixCB->AutoSize = true;
			this->SSEFixCB->Location = System::Drawing::Point(12, 58);
			this->SSEFixCB->Name = L"SSEFixCB";
			this->SSEFixCB->Size = System::Drawing::Size(60, 17);
			this->SSEFixCB->TabIndex = 4;
			this->SSEFixCB->Text = L"SSEFix";
			this->SSEFixCB->UseVisualStyleBackColor = true;
			this->SSEFixCB->CheckedChanged += gcnew System::EventHandler(this, &SettingsForm::SSEFixCB_CheckedChanged);
			// 
			// ColorMaskFore
			// 
			this->ColorMaskFore->FormattingEnabled = true;
			this->ColorMaskFore->Items->AddRange(gcnew cli::array< System::Object^  >(16) {L"0-Black", L"1-Blue", L"2-Green", L"3-Cyan", 
				L"4-Red", L"5-Magenta", L"6-Brown", L"7-LightGray", L"8-DarkGray", L"9-LightBlue", L"10-LightGreen", L"11-LightCyan", L"12-LightRed", 
				L"13-LightMagenta", L"14-Yellow", L"15-White"});
			this->ColorMaskFore->Location = System::Drawing::Point(136, 35);
			this->ColorMaskFore->Name = L"ColorMaskFore";
			this->ColorMaskFore->Size = System::Drawing::Size(92, 21);
			this->ColorMaskFore->TabIndex = 5;
			this->ColorMaskFore->SelectedIndexChanged += gcnew System::EventHandler(this, &SettingsForm::ColorMaskFore_SelectedIndexChanged);
			// 
			// ColorMaskBack
			// 
			this->ColorMaskBack->FormattingEnabled = true;
			this->ColorMaskBack->Items->AddRange(gcnew cli::array< System::Object^  >(8) {L"0-Transparent", L"16-Black", L"32-Gray", 
				L"48-White", L"64-Cyan", L"80-Green", L"96-Red", L"112-Yellow"});
			this->ColorMaskBack->Location = System::Drawing::Point(136, 62);
			this->ColorMaskBack->Name = L"ColorMaskBack";
			this->ColorMaskBack->Size = System::Drawing::Size(92, 21);
			this->ColorMaskBack->TabIndex = 6;
			this->ColorMaskBack->SelectedIndexChanged += gcnew System::EventHandler(this, &SettingsForm::ColorMaskBack_SelectedIndexChanged);
			// 
			// HideDllLoadCB
			// 
			this->HideDllLoadCB->AutoSize = true;
			this->HideDllLoadCB->Location = System::Drawing::Point(276, 35);
			this->HideDllLoadCB->Name = L"HideDllLoadCB";
			this->HideDllLoadCB->Size = System::Drawing::Size(87, 17);
			this->HideDllLoadCB->TabIndex = 7;
			this->HideDllLoadCB->Text = L"Hide DllLoad";
			this->HideDllLoadCB->UseVisualStyleBackColor = true;
			this->HideDllLoadCB->CheckedChanged += gcnew System::EventHandler(this, &SettingsForm::HideDllLoadCB_CheckedChanged);
			// 
			// HideDllUnloadCB
			// 
			this->HideDllUnloadCB->AutoSize = true;
			this->HideDllUnloadCB->Location = System::Drawing::Point(276, 58);
			this->HideDllUnloadCB->Name = L"HideDllUnloadCB";
			this->HideDllUnloadCB->Size = System::Drawing::Size(97, 17);
			this->HideDllUnloadCB->TabIndex = 8;
			this->HideDllUnloadCB->Text = L"Hide DllUnload";
			this->HideDllUnloadCB->UseVisualStyleBackColor = true;
			this->HideDllUnloadCB->CheckedChanged += gcnew System::EventHandler(this, &SettingsForm::HideDllUnloadCB_CheckedChanged);
			// 
			// HideBreakpointCB
			// 
			this->HideBreakpointCB->AutoSize = true;
			this->HideBreakpointCB->Location = System::Drawing::Point(276, 81);
			this->HideBreakpointCB->Name = L"HideBreakpointCB";
			this->HideBreakpointCB->Size = System::Drawing::Size(102, 17);
			this->HideBreakpointCB->TabIndex = 9;
			this->HideBreakpointCB->Text = L"Hide Breakpoint";
			this->HideBreakpointCB->UseVisualStyleBackColor = true;
			this->HideBreakpointCB->CheckedChanged += gcnew System::EventHandler(this, &SettingsForm::HideBreakpointCB_CheckedChanged);
			// 
			// CancelBtn
			// 
			this->CancelBtn->Location = System::Drawing::Point(305, 120);
			this->CancelBtn->Name = L"CancelBtn";
			this->CancelBtn->Size = System::Drawing::Size(75, 23);
			this->CancelBtn->TabIndex = 10;
			this->CancelBtn->Text = L"Cancel";
			this->CancelBtn->UseVisualStyleBackColor = true;
			this->CancelBtn->Click += gcnew System::EventHandler(this, &SettingsForm::CancelBtn_Click);
			// 
			// SaveBtn
			// 
			this->SaveBtn->Location = System::Drawing::Point(224, 120);
			this->SaveBtn->Name = L"SaveBtn";
			this->SaveBtn->Size = System::Drawing::Size(75, 23);
			this->SaveBtn->TabIndex = 11;
			this->SaveBtn->Text = L"Save";
			this->SaveBtn->UseVisualStyleBackColor = true;
			this->SaveBtn->Click += gcnew System::EventHandler(this, &SettingsForm::SaveBtn_Click);
			// 
			// SettingsForm
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(392, 155);
			this->Controls->Add(this->SaveBtn);
			this->Controls->Add(this->CancelBtn);
			this->Controls->Add(this->HideBreakpointCB);
			this->Controls->Add(this->HideDllUnloadCB);
			this->Controls->Add(this->HideDllLoadCB);
			this->Controls->Add(this->ColorMaskBack);
			this->Controls->Add(this->ColorMaskFore);
			this->Controls->Add(this->SSEFixCB);
			this->Controls->Add(this->LogHideCB);
			this->Controls->Add(this->FollowDumpCB);
			this->Controls->Add(this->CopyFormatCB);
			this->Controls->Add(this->ColorMaskCB);
			this->Name = L"SettingsForm";
			this->Text = L"HOlly Settings";
			this->Load += gcnew System::EventHandler(this, &SettingsForm::SettingsForm_Load);
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion

private: System::Void SaveBtn_Click(System::Object^  sender, System::EventArgs^  e) {
			 Sets->Save();
			 Sets->Changed();
			 this->Close();
		 }
private: System::Void CancelBtn_Click(System::Object^  sender, System::EventArgs^  e) {
			 Sets->Clear();
			 Sets->Changed();
			 this->Close();
		 }
private: System::Void CopyFormatCB_CheckedChanged(System::Object^  sender, System::EventArgs^  e) {
			 Sets->Set("CopyFormat-Enabled", CopyFormatCB->Checked);
			 Sets->Changed();
		 }
private: System::Void FollowDumpCB_CheckedChanged(System::Object^  sender, System::EventArgs^  e) {
			 Sets->Set("FollowDump-Enabled", FollowDumpCB->Checked);
			 Sets->Changed();
		 }
private: System::Void SSEFixCB_CheckedChanged(System::Object^  sender, System::EventArgs^  e) {
			 Sets->Set("SSEFix-Enabled", SSEFixCB->Checked);
			 Sets->Changed();
		 }
private: System::Void ColorMaskCB_CheckedChanged(System::Object^  sender, System::EventArgs^  e) {
			 Sets->Set("ColorMask-Enabled", ColorMaskCB->Checked);
			 Sets->Changed();
		 }
private: System::Void ColorMaskFore_SelectedIndexChanged(System::Object^  sender, System::EventArgs^  e) {
			 Sets->Set("ColorMask-Foreground", ColorMaskFore->SelectedIndex);
			 Sets->Changed();
		 }
private: System::Void ColorMaskBack_SelectedIndexChanged(System::Object^  sender, System::EventArgs^  e) {
			 Sets->Set("ColorMask-Background", (unsigned int)ColorMaskBack->SelectedIndex << 4);
			 Sets->Changed();
		 }
private: System::Void LogHideCB_CheckedChanged(System::Object^  sender, System::EventArgs^  e) {
			 Sets->Set("LogHide-Enabled", LogHideCB->Checked);
			 Sets->Changed();
		 }
private: System::Void HideDllLoadCB_CheckedChanged(System::Object^  sender, System::EventArgs^  e) {
			 int num = Sets->Get("LogHide-HideMask", 0);
			 num = (HideDllLoadCB->Checked) ? num | 1 : num & ~1;
			 Sets->Set("LogHide-HideMask", num);
			 Sets->Changed();
		 }
private: System::Void HideDllUnloadCB_CheckedChanged(System::Object^  sender, System::EventArgs^  e) {
			 int num = Sets->Get("LogHide-HideMask", 0);
			 num = (HideDllUnloadCB->Checked) ? num | 2 : num & ~2;
			 Sets->Set("LogHide-HideMask", num);
			 Sets->Changed();
		 }
private: System::Void HideBreakpointCB_CheckedChanged(System::Object^  sender, System::EventArgs^  e) {
			 int num = Sets->Get("LogHide-HideMask", 0);
			 num = (HideBreakpointCB->Checked) ? num | 4 : num & ~4;
			 Sets->Set("LogHide-HideMask", num);
			 Sets->Changed();
		 }
};
}
