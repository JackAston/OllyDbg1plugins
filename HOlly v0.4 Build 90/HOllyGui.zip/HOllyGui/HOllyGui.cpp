// HOllyGui.cpp : Defines the exported functions for the DLL application.
//

#include "stdafx.h"
#include "Settings.h"
#include "PatchManager.h"
#include "SettingsForm.h"

using namespace HOllyGui;

extern "C" __declspec(dllexport) bool ShowForm(HOlly::Settings* sets, HOlly::PatchManager* pm)
{
	SettingsForm^ sf = gcnew SettingsForm();
	sf->Sets = sets;
	Application::Run(sf);
	return true;
}