//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by lblmk.rc
//
#define IDD_LABELMAKER                  101
#define IDD_LABELDELETE                 102
#define IDC_EDT_LABELNAME               1000
#define IDC_EDT_TOPADDR                 1001
#define IDC_RDO_BYTE                    1002
#define IDC_RDO_WORD                    1003
#define IDC_RDO_DWORD                   1004
#define IDC_EDT_NUMBER                  1005
#define IDC_RDO_DEC                     1006
#define IDC_RDO_HEX                     1007
#define IDC_RDO_STRUCT                  1008
#define IDC_CMB_STRUCT                  1009
#define IDC_LST_DETAIL                  1012
#define IDC_SPN_NUMBER                  1013
#define IDC_CMB_ALIGN                   1014
#define IDC_BTN_DELETE                  1015
#define IDC_BTN_DELSEL                  1016
#define IDC_LST_LABEL                   1017

#define IDM_DELLBLLIST                  200
#define IDM_VIEWCPUDUMP                 40001
#define IDM_DELLABEL                    40002

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        105
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1017
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
