#pragma once
//------------------------PE file structures------------------
struct FILE_HEADER
{
	unsigned short machine;
	unsigned short number_of_sections;
	unsigned long timedatestamp;
	unsigned long pointerToSymbolTable;
	unsigned long number_of_symbols;
	unsigned short SizeOfOptionalHeader;
	unsigned short characteristics;
};

struct DATA_DIRECTORY
{
	unsigned long rva;
	unsigned long size;
};

struct OPTIONAL_HEADER
{
	unsigned short magic;
	unsigned char MajorLinkerVersion;
	unsigned char MinorLinkerVerson;
	unsigned long SizeOfCode;
	unsigned long SizeOfIniData;
	unsigned long SizeOfUnIniData;
	unsigned long EP;
	unsigned long BaseOfCode;
	unsigned long BaseOfData;
	unsigned long   ImageBase;
    unsigned long   SectionAlignment;
    unsigned long   FileAlignment;
    unsigned short    MajorOperatingSystemVersion;
    unsigned short    MinorOperatingSystemVersion;
    unsigned short    MajorImageVersion;
    unsigned short    MinorImageVersion;
    unsigned short    MajorSubsystemVersion;
    unsigned short    MinorSubsystemVersion;
    unsigned long   Win32VersionValue;
    unsigned long   SizeOfImage;
    unsigned long   SizeOfHeaders;
    unsigned long   CheckSum;
    unsigned short    Subsystem;
    unsigned short    DllCharacteristics;
    unsigned long   SizeOfStackReserve;
    unsigned long   SizeOfStackCommit;
    unsigned long   SizeOfHeapReserve;
    unsigned long   SizeOfHeapCommit;
    unsigned long   LoaderFlags;
    unsigned long   NumberOfRvaAndSizes;
    DATA_DIRECTORY DataDirectory[16];
};
struct NT_FILE_HEADER
{
	unsigned long signature;
	FILE_HEADER fheader;
	OPTIONAL_HEADER opheader;
};
struct SECTION_HEADER
{
	char name[8];
	unsigned long vsize;
	unsigned long voffset;
	unsigned long rawsize;
	unsigned long rawoffset;
	unsigned long pRelocations;
	unsigned long pLineNumbers;
	unsigned short Num_relocations;
	unsigned short Num_linenumbers;
	unsigned long characteristics;
};

struct IMPORT_DESCRIPTOR
{
	 unsigned long ofthunk;          //static file and at runtime,both cases hold (pointer to function hint and name) or function ordinal.
	 unsigned long tdstamp;
	 unsigned long frwderchain;
	 unsigned long name;             //dll name.
	 unsigned long fthunk;           //at runtime,containing resolved function addresses.
};

struct TLS_SHIT
{
	int A,B;
	int* pIndex;
	void(__stdcall **ft)(void*,int,int);
	int C,D;
};

int num_sections;
SECTION_HEADER* psections;
unsigned long RvaToRaw(unsigned long rva)
{
	if(num_sections==0)
	{
		return 0;
	}
	for(int i=0;i<num_sections;i++)
	{
		if((rva>=psections[i].voffset)&&(rva<(psections[i].voffset+psections[i].vsize))) //in range
		{
			return (psections[i].rawoffset+(rva-psections[i].voffset));
		}
	}
	return 0;
}

//-------------------------------------------------------------------