// plug.cpp : Defines the entry point for the DLL application.
#include "stdafx.h"
#define _CHAR_UNSIGNED
#include "windows.h"
#include "plugin.h"
#include "pe.h"
#include "str.h"
//---------------------------------------------------------------------------------
HWND mainWnd;


//---------exports-------------------------
extern "C"
{
_declspec(dllexport)  int __cdecl ODBG_Plugindata(char shortname[32]) 
{
    strcpy(shortname,"ICanATTach");       // Name of plugin
    return 110;   //version 1.10
}
_declspec(dllexport) int __cdecl ODBG_Plugininit(int ollydbgversion,HWND hw,ulong *features) 
{
  mainWnd=hw;
  Addtolist(0,0,"ICanATTach");
  Addtolist(0,-1,"started successfully");
  return 0;
}
_declspec(dllexport) int __cdecl ODBG_Pluginmenu(int origin,char data[4096],void *item)
{
   if(origin==PM_MAIN)
   {
		strcpy(data,"0 &About");
		return 1;
   }
   return 0;
}
_declspec(dllexport) void __cdecl ODBG_Pluginaction(int origin,int action,void *item) 
{
  if (origin==PM_MAIN) 
  {
	  if(action==0)		  MessageBox(mainWnd,"ICanATTach by waliedassar\n waliedassar@gmail.com","walied",MB_OK|MB_ICONINFORMATION);
  }
}

}





//------------------------

void* ptr;
void* jumpback;


unsigned long pid;
HANDLE h;
void* DbgUiRemoteBreakin_addr;
void* ExitThread_addr;
void* NtContinue_addr;

unsigned char code[8];


unsigned long oldd;
unsigned long written;
unsigned long olddd;
unsigned char* pContinue;


unsigned long relativeAddr(unsigned long from,unsigned long to)
{
	unsigned long diff=0;
	if(from>to)
	{
		 //  5-byte jump instruction
         diff=((unsigned long)from+5)-(unsigned long)to;
		 diff=-diff;
	}
	else
	{
          diff=(unsigned long)to-((unsigned long)from+5);
	}
	return diff;
}
void __stdcall funW()
{
      DbgUiRemoteBreakin_addr=(void*)GetProcAddress(GetModuleHandle("ntdll.dll"),"DbgUiRemoteBreakin");
      NtContinue_addr=(void*)GetProcAddress(GetModuleHandle("ntdll.dll"),"ZwContinue");
	  ExitThread_addr=(void*)GetProcAddress(GetModuleHandle("kernel32.dll"),"ExitThread");
      
	  unsigned char* p=&code[0];
	  *p=0xCC;
	  p++;
	  *p=0x68;
	  p++;
	  *(unsigned long*)(p)=(unsigned long)ExitThread_addr;
	  p+=4;
	  *p=0xC3;
}

__declspec(naked) mine()
{
	//extract the debugged process PID
	__asm push ebp
	__asm mov ebp,esp

	__asm pushad
	__asm mov eax,dword ptr[ebp+0x8]
	__asm mov pid,eax
    h=OpenProcess(PROCESS_ALL_ACCESS,TRUE,pid);
    if(!h) goto bye;
	funW();
	VirtualProtectEx(h,DbgUiRemoteBreakin_addr,0x7,PAGE_EXECUTE_READWRITE,&oldd);
	VirtualProtectEx(h,NtContinue_addr,0x100,PAGE_EXECUTE_READWRITE,&olddd);

	WriteProcessMemory(h,DbgUiRemoteBreakin_addr,code,0x7,&written);
    

	pContinue=(unsigned char*)NtContinue_addr;
	while(   (*(unsigned long*)pContinue&0x00FFFFFF)!=0x0008c2   )  //ret 0x8
	{
		unsigned char tmp=*(unsigned char*)pContinue;
		WriteProcessMemory(h,pContinue,&tmp,0x1,&written);
		pContinue++;
	}
	WriteProcessMemory(h,pContinue,"\xC2\x08\x00",0x3,&written);



	//Restore page access rights
	VirtualProtectEx(h,NtContinue_addr,0x100,olddd,&olddd);
	VirtualProtectEx(h,DbgUiRemoteBreakin_addr,0x7,oldd,&oldd);

	CloseHandle(h);

	//reset global vars
	h=0;
bye:
	__asm popad
	__asm mov eax,jumpback
	__asm jmp eax
}

//------------------------------

BOOL APIENTRY Dllmain(HMODULE hModule,int reason,LPVOID lpReserved)
{
	if(reason!=DLL_PROCESS_ATTACH) return FALSE;

	ptr=(void*)GetProcAddress(GetModuleHandle("kernel32.dll"),"DebugActiveProcess");
    
	if(!ptr) return 0;
	
	unsigned char x[5]={0};
	memcpy(x,ptr,5); //backup the first 5 bytes of Prologue
    
	jumpback=(unsigned char*)ptr+5;
	
	unsigned long old=0;
	VirtualProtect(ptr,0x5,PAGE_EXECUTE_READWRITE,&old);

	//patching here
	unsigned char* px=(unsigned char*)ptr;
	*px=0xE9;
	px++;
	*(unsigned long*)px=relativeAddr((unsigned long)ptr,(unsigned long)&mine);

	VirtualProtect(ptr,0x5,old,&old);

    return TRUE;
}
