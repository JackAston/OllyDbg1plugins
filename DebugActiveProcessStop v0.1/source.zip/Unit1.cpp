#define NO_WIN32_LEAN_AND_MEAN
#include <vcl.h>

#pragma hdrstop
#pragma package(smart_init)
#include "plugin.h"
#include "madkernel.hpp"



HINSTANCE        hinst=0;                // DLL instance
HWND             hwmain=0;               // Handle of main OllyDbg window

//---------------------------------------------------------------------------
bool WINAPI DllMain(HANDLE hModule, DWORD fdwReason, LPVOID lpReserved)

{
  if (fdwReason == DLL_PROCESS_ATTACH)
   {

        hinst=hModule;


   } 
        return true;
}

//---------------------------------------------------------------------------
 
extc int _export cdecl ODBG_Plugindata(char shortname[32]) {
  strcpy(shortname,"DebugActiveProcessStop");    // Name of command line plugin
  return PLUGIN_VERSION;
}
extc int _export cdecl ODBG_Plugininit(int ollydbgversion,HWND hw,ulong *features) {


  if (ollydbgversion<PLUGIN_VERSION)
    return -1;

   hwmain=hw;

   Addtolist(0,0,"DebugActiveProcessStop plugin");
  Addtolist(0,-1,
   "DebugActiveProcessStop plugin \n"
          "(stop debug target process and let's target running alone)\n"
          "Copyright (C) 2004 Teerayoot");

  return 0;
}

extc int _export cdecl ODBG_Pluginmenu(int origin,char data[4096],void *item) {
  if (origin!=PM_MAIN)
    return 0;                          // No pop-up menus in OllyDbg's windows


   strcpy(data,"0 &Stop|1 &About");
  return 1;
}

extc void _export cdecl ODBG_Pluginaction(int origin,int action,void *item) {

         switch(action){
         case 0 :   {
             
           DebugActiveProcessStop(Madkernel::Thread(Getcputhreadid())->OwnerProcess->ID);
          
                  
                  MessageBox(hwmain,SysErrorMessage( GetLastError()).c_str(),
          
          "DebugActiveProcessStop plugin",MB_OK|MB_ICONINFORMATION);



                 break;
                }
         case 1 :  {


                    MessageBox(hwmain,
          "DebugActiveProcessStop plugin \n"
          "(stop debug target process and let's target running alone)\n"
          "Copyright (C) 2004 Teerayoot",
          "DebugActiveProcessStop plugin",MB_OK|MB_ICONINFORMATION);
                  break;
                }
         }
}

extc int _export cdecl ODBG_Pluginclose(void) {

  return 0;
}
 extc void _export cdecl ODBG_Pluginmainloop(DEBUG_EVENT *debugevent) {


           

      
    
}


