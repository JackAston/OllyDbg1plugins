#define IDD_DELSESOPT                   101
#define IDC_CONFIRM                     1010
#define IDC_NOTEXIST                    1011
#define IDC_CHKOTHERPATH                1012

#define IDD_SESSIONLIST                 102
#define IDC_SESSIONLIST                 1020
#define IDC_BTN_DELALL                  1021
#define IDC_BTN_DELNODBGE               1022
#define IDC_BTN_DELBAK                  1023
