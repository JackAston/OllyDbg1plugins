Hello there,

In February last year I wrote simple plugin that in a little bit 
embellishes OllyDbg. In fact, it allows you to edit EIP register 
(i.e. to jumping back in code) and removes some superfluous 
positions from Olly main popup menu (i.e Comment, 
Label elements- assuming we are using keyboard shortcuts - 
this is handy not only for cleaning this popup but also to 
make popup menu shorter). 

Frankly speaking, this plugin does nothing special 
despite providing ability to edit EIP and removing 
this superfluous elements from popup menu. 

MGeeky 2010-11
 
